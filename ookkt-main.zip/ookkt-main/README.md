﻿# Xray快速部署到Heroku/Okteto

Vless & Vmess: 

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://dashboard.heroku.com/new?template=https://github.com/UTun4/ookkt.git) 

[![Develop on Okteto](https://okteto.com/develop-okteto.svg)](https://cloud.okteto.com/deploy)



默认访问

XXX.herokuapp.com/v2link/index.html

或 

XXX.cloud.okteto.net/v2link/index.html

获取vless、vmess链接和二维码

![](show.png)



## Heroku部署问题

如果遇到：

> We couldn't deploy your app because the source code violates the Salesforce Acceptable Use and External-Facing Services Policy.

请Fork一下仓库，然后在自己的仓库下点击。



## 自定义静态HTML页面
仓库地址
```
https://github.com/happyevero/Html
```

#### WELCOME TO THE CAFESTORE [OK]
```
https://github.com/happyevero/Html/raw/main/CAFESTORE-html.zip
```
#### Soundwave  [OK]
```
https://github.com/happyevero/Html/raw/main/S-html.zip
```
#### Lokuri Website [OK]
```
https://github.com/happyevero/Html/raw/main/L-html.zip
```
#### FitApp [OK]
```
https://github.com/happyevero/Html/raw/main/FitApp-html.zip
```
####  KayDen [OK]
```
https://github.com/happyevero/Html/raw/main/KayDen-html.zip
```
#### LandingStartups
```
https://github.com/happyevero/Html/raw/main/LandingStartups-html.zip
```
#### MeetApril
```
https://github.com/happyevero/Html/raw/main/MeetApril-html.zip
```

#### Comila
```
https://github.com/happyevero/Html/raw/main/comila-html.zip 
```

#### RECIPES
```
https://github.com/happyevero/Html/raw/main/RECIPES-html.zip
```
####  GoidFood
```
https://github.com/happyevero/Html/raw/main/GoidFood-html.zip
```
#### Tuxedo
```
https://github.com/happyevero/Html/raw/main/Tuxedo-html.zip
```
#### BrainStorm
```
https://github.com/happyevero/Html/raw/main/BrainStorm-html.zip
```
